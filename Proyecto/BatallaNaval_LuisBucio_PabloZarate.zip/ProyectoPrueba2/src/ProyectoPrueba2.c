#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <winsock2.h>

int enviarRecibir();
void barcos(int C[][10], int B, float A);
float dificultad(int A);
void copiaArreglo(int A[][10], int B[][10], int C);
void juego(int A[][10], int B[][10], float C, int D);
void printMatriz(int A[][10], int B);
void BannerBatallaNaval();
void BannerFinDelJuego();
void BannerFallaste();
void BannerImpacto();
void BannerBomba();
void BannerPerdiste();
void BatallaNavalIndividual();
void BannerNosDieron();
void BannerFallo();
int recvfromTimeOutUDP(SOCKET socket, long sec, long usec);
void BatallaNavalMultiplayer();
void insertarBarcos(int A[][10], int B, int C);
void juegoMultiplayerCliente(int A[][10], int B[][10], int C);
void juegoMultiplayerServer(int A[][10], int B[][10], int C);
void juegoMultiplayer(int A[][10], int B[][10], int C);
void minas(int C[][10], int B, float A);
float dificultadminas();
void copiaArregloMinas(int A[][10], int B[][10], int C);
void juegoMinas(int A[][10], int B[][10], float C, int D);
void printMatrizMinas(int A[][10], int B);
void Buscaminas();
int ServerX();
int ServerY();
int ClientX();
int ClientY();
int ClientHIT();
int ClientFAIL();

int main (){
    char opcion[2];
    do{
        printf("\t***MENU***\n");
        printf("1. Batalla Naval Individual\n2. Batalla Naval Multijugador\n3. Buscaminas\n4. Salir\n");
        printf("\n\nOPCION: ");
        scanf("%s", opcion);
    	getchar();
        switch(opcion[0]){
            case '1':
                BatallaNavalIndividual();
                break;
            case '2':
                BatallaNavalMultiplayer();
                break;
            case '3':
            	Buscaminas();
                break;
            case '4':
                printf("�GRACIAS POR JUGAR! ADIOS\n");
                exit(0);
            default:
                printf("Opcion invalida. \n");
                break;
        }
    }while(opcion[0]!='4');
    return 0;
}
void BatallaNavalIndividual(){
  srand(time(0));
  char tam[2];
  int mapa[10][10], w = 0, u = 0, o = 0, ships[10][10];
  float dif;
  BannerBatallaNaval();
  printf ("Tamano del juego (C/M/G): ");
  gets (tam);
  switch (tam[0]){
    case 'G':
    case 'g':
        printf ("Escogiste el tamano grande. (10*10)\n");
        printf ("\t");
        for (int p = 0; p < 10; p++){
            printf ("%d ", p);
        }
        printf ("\n");
        for (int i = 0; i < 10; i++){
        printf ("\n");
        printf ("%d\t", w);
        w++;
        for (int q = 0; q < 10; q++){
            mapa[i][q] = '+';
            printf ("%c ", mapa[i][q]);
            }
        }
        printf("\n\n");
        dif = dificultad (100);
        copiaArreglo(mapa, ships, 10);
        barcos (ships, 9, dif);
        juego(mapa, ships, dif, 10);
        break;
    case 'M':
    case 'm':
        printf ("Escogiste el tama�o mediano. (7*7)\n");
        printf ("\t");
        for (int p = 0; p < 7; p++){
            printf ("%d ", p);
            }
        printf ("\n");
        for (int e = 0; e < 7; e++){
            printf ("\n");
            printf ("%d\t", u);
            u++;
            for (int r = 0; r < 7; r++){
                mapa[e][r] = '+';
                printf ("%c ", mapa[e][r]);
            }
        }
        printf("\n\n");
        dif = dificultad (49);
        copiaArreglo(mapa, ships, 7);
        barcos (ships, 6, dif);
        juego(mapa, ships, dif, 7);
        break;
    case 'C':
    case 'c':
        printf ("Escogiste el tama�o chico. (5*5)\n");
        printf ("\t");
        for (int p = 0; p < 5; p++){
            printf ("%d ", p);}
        printf ("\n");
        for (int t = 0; t < 5; t++){
            printf ("\n");
            printf ("%d\t", o);
            o++;
            for (int y = 0; y < 5; y++){
                mapa[t][y] = '+';
                printf ("%c ", mapa[t][y]);
            }
        }
        printf("\n\n");
        dif = dificultad (25);
        copiaArreglo(mapa, ships, 5);
        barcos (ships, 4, dif);
        juego(mapa, ships, dif, 5);
        break;
    default:
        printf ("Tama�o invalido.");
        break;
    }
}
void barcos(int C[][10], int B, float A){
    srand(time(0));
    for (int i = 0; i < A; i++){
        C[rand() % B][rand() % B] = 'o';
    }
}
float dificultad(int A){
  char dif[2];
  printf ("INSERTA LA DIFICULTAD (F/M/D): ");
  scanf ("%c", dif);
  switch (dif[0]){
        case 'F':
        case 'f':
            return (float)A / 2.5;
            break;
        case 'M':
        case 'm':
            return (float)A / 3.5;
            break;
        case 'D':
        case 'd':
            return (float)A / 5;
            break;
        default:
            printf("\nDIFICULTAD INVALIDA, INSERTE DE NUEVO\n");
            return dificultad(A);
            break;
        }
}
void copiaArreglo(int A[][10], int B[][10], int C){
    for(int i=0;i<C;i++){
        for(int j=0;j<C;j++){
            B[i][j]=A[i][j];
        }
    }
}
void printMatriz(int A[][10], int B){
    int u=0;
    printf ("\n");
    printf ("\t");
    for (int p = 0; p < B; p++){
        printf ("%d ", p);
        }
    printf ("\n");
    for (int e = 0; e < B; e++){
        printf ("\n");
        printf ("%d\t", u);
        u++;
        for (int r = 0; r < B; r++){
            printf ("%c ", A[e][r]);
        }
    }
    printf ("\n\n");
}
void juego(int A[][10], int B[][10], float C, int D){
    int x, y, cont=0, intentos = C+C/3;
    float gan;
    do{
        printf("INSERTA LA COORDENADA EN X: ");
        scanf("%d", &x);
        printf("INSERTA LA COORDENADA EN Y: ");
        scanf("%d", &y);
        printf("\n");
        if(B[x][y]=='o'){
            if(A[x][y]=='o'){
                printf("\nCOORDENADA USADA, TE QUEDAN %d INTENTOS\n", intentos-cont+1);
            }
            else{
                BannerImpacto();
                BannerBomba();
                printf("\nTE QUEDAN %d INTENTOS\n", intentos-cont);
                A[x][y]='O';
                printMatriz(A, D);
                cont++;
                gan++;
                if(gan==C){
                    printf("\n�FELICIDADES! GANASTE\n");
                }
            }
        }
        else{
            if(A[x][y]=='X'){
                printf("\nCOORDENADA USADA, TE QUEDAN %d INTENTOS\n", intentos-cont+1);
            }
            else{
                BannerFallaste();
                printf("\nTE QUEDAN %d INTENTOS\n", intentos-cont);
                A[x][y]='X';
                printMatriz(A, D);
                cont++;
                if(cont==intentos){
                BannerPerdiste();
                }
            }

        }

        printf("\n");
    }while(cont!=intentos);
    BannerFinDelJuego();
}
void BannerBatallaNaval(){
    printf("========================================================================================\n\
=      ========================  ==  ==============  =======  =======================  =\n\
=  ===  =======================  ==  ==============   ======  =======================  =\n\
=  ====  ==========  ==========  ==  ==============    =====  =======================  =\n\
=  ===  ====   ===    ===   ===  ==  ===   ========  ==  ===  ===   ===  =  ===   ===  =\n\
=      ====  =  ===  ===  =  ==  ==  ==  =  =======  ===  ==  ==  =  ==  =  ==  =  ==  =\n\
=  ===  ======  ===  ======  ==  ==  =====  =======  ====  =  =====  ===   ======  ==  =\n\
=  ====  ===    ===  ====    ==  ==  ===    =======  =====    ===    ===   ====    ==  =\n\
=  ===  ===  =  ===  ===  =  ==  ==  ==  =  =======  ======   ==  =  ==== ====  =  ==  =\n\
=      =====    ===   ===    ==  ==  ===    =======  =======  ===    ==== =====    ==  =\n\
========================================================================================\n\
");
}
void BannerFinDelJuego(){
    printf("\n\
=======================================================================================================================\n\
=        ==    ==  =======  =======       ===        ==  =================    ==  ====  ==        ===      =====    ===\n\
=  =========  ===   ======  =======  ====  ==  ========  ==================  ===  ====  ==  ========   ==   ===  ==  ==\n\
=  =========  ===    =====  =======  ====  ==  ========  ==================  ===  ====  ==  ========  ====  ==  ====  =\n\
=  =========  ===  ==  ===  =======  ====  ==  ========  ==================  ===  ====  ==  ========  ========  ====  =\n\
=      =====  ===  ===  ==  =======  ====  ==      ====  ==================  ===  ====  ==      ====  ========  ====  =\n\
=  =========  ===  ====  =  =======  ====  ==  ========  ==================  ===  ====  ==  ========  ===   ==  ====  =\n\
=  =========  ===  =====    =======  ====  ==  ========  =============  ===  ===  ====  ==  ========  ====  ==  ====  =\n\
=  =========  ===  ======   =======  ====  ==  ========  =============  ===  ===   ==   ==  ========   ==   ===  ==  ==\n\
=  ========    ==  =======  =======       ===        ==        ========     =====      ===        ===      =====    ===\n\
=======================================================================================================================\n\
");
}
void BannerBomba(){
    printf("\
                                \n\
NNXNNNXXNNXXNNXXNNXXNNXXNNXXXXKO000KXK0OO000KXXXXNWNXXNNXXNNNXNWNXNNNXNNNXNNNXXNNXXNNXXNNXXNNNXNNXXN\n\
XNNNXXNNXXNNXXNNXXNNNXNNXXXK0kkkO0OkxddxxddddddkKXXXNNXXNNXXNNXXNWXXNNNXXNNXNNNXXNNXXNNXXNNXXNWXXNWN\n\
NNXNWNXNNNXXNNXXNNXXNWXKKKkxO0O0XXKxodxxkxooool::x0XXXNNXXNNXXXNXXNWNXNNXXNNNXXNNXXNNXXNNXXNNXXNNNXN\n\
XNWNXXNNXXNNXXNNXXNNXKKOOOOkkkOKXXOdooloddddoodd:''c0XXXNNXXNNXXNNNXNNNXXNNXXNNXXNNXXNNXXNNXXNNXXNNN\n\
NNXNNNXXWNXXWNXXNNKXXKOOKKOxdxkO0Odooooloxxxddxdc,';lxkkxk0NXXNWNXNNNXNNNXXNNXNNNXXNNXXNNXXNNXXNNNXN\n\
XNNNXXWNXXNNXXXXK0K0xdxOOxddxkO00xcclc:coxkO00Okxxxkxlccl:;l0NXXNWNXNWNXNWNXXWNXXNNXXNNXXNNXXNNXXNNN\n\
NNXXNNXXNX0kdoc::llccldkdc:cdk00Oxoccc:;lOKXXK00OOkxdllxOkxodk0XXKNWNXNWNXXNNXXNNXXNNXXNNXXNNXXNNNXN\n\
XXWNXXN0olllcc:;cdkO0KXXKkdlldO00KOxdxxk0XXNNXK0OxxxxxddkKXXKxclONXKXWNXXNNXXNNXXNNXXNNXXNNXXNNXXNNN\n\
NNXNNXk:;ldxxxxxkO00XNNNNNK0O0XXNNNNNNNNNNXXXKK0000OOOOkk0XKOxl;ckXNXXXNNXXNNXXNNXXNNXXNNXXNNXXNNNXN\n\
XNNNXx:cdxxdxxxxxk0KXXNNNNXKXNWWWWWWWNNNNNNXX00OOkkxxxkOO0K0kxoc:cOKXNXKXNNXXNNXXNNXXNNXXNNXXNNXXNWN\n\
NNXXx,:oxkOxddooodk0KXNNXK000XNWWWWNXXXNNK00KKXKOxxxxddxkOOOOOxl;,oKXKXNNXNNNXXNNXXNNXXNNXXNNXXNNNXN\n\
XXWXl,:cdO0OxkxddxO00KXNX0000KNNXK0Ok0XNXKkdx0XXXKKKKOxdxOOOOK0kolddOXXKXNXXXNNXXNNXXNNXXNNXXNNXXNNN\n\
NNXXx;:loxOOkOO00OkkO0KK00KKKXXK0OkkOKXXNNX0OKNWWWWNNNX00XXXXXNNXKkkkkKXXXXNNXXNNXXNNXXNNXXNNXXNNNXN\n\
XNNN0o,,codxxOOOOOOkxkOOOOkO0KK00KXXNNXNNNXXKXNNWNNNNNNNNXXXXXXXXKOOkdxOKKKKXNNXXNNXXNNXXNNXXNNXXNNN\n\
NNXXN0l,;coodxOOkkOOO0OO0OxxkO0KKKKXNNXXNNNXKKKXXNNNWWWNXNXNNXXXNK0Oxddk000000KXNXXNNXXNNXXNNNXNNXXN\n\
XNNXKKk:.,:clxkOkk00KKKKKkdkO0KK00KXXNX0KNNXKOkkk0KKXNNNNNNNXXXK0OkxdlclOK000OxxOXXXXNNXXNNXXNNNXNNX\n\
NNXNNX0l'..',ldxxkkkO0KXXOdxOOOOkk0KXXK00XXXK00kxxkkOOKXNNXXXXXK0kxdddxk0KXKK0xclkKXXXXXXXXXNNXNNXXN\n\
XNNNXXXk;....',,:ldxk000XKxoodddodk000KK00OO000OkkkkkxkO00KXKK0OkxkO00K0OO0000kllxxkO00000000KNXXNNN\n\
NNXNNNXXk;....''',cok0KKKK0xccclldxkOKXKK0kxkOK0Okkkkkkkxk0K0OkxooxO000OkO0OKK0kOOkkO00OOkxkxx0XNNNN\n\
XNNNXNNNX0kc,,,''';::cldxkOxlllclxOO0XKO0Oxdxk0XK0000KK0OO0OxdddxkO00Okdx0XXX0kkkOOOxxkkxdxxdk0XXNNN\n\
NNXNNNXNNNXXKd:'......';cdxdodoodxkOOOOxxkkxddxOKKKKKKKKKXXX0OO0KKKK0OkkkKXK0kddxkOkddooodxxk0XXXNNN\n\
XNNNXNNNXXNNNNXOc. ....';:clolodxkkxdddddxkxoolok0000000KXXNNXX0kxkOOOkkk0X0OOOOkkkdddolodxOKXNXXNNN\n\
NNXXNXNNNNXXNKxoc;.....',;;cc::loddoc::clooooooldOOkkkOO0KK00KKOkxxddxxdk00O00kkkddxdlclxOKXNXXXNNNN\n\
NNNXNNXXXXXXXKkollxdc;;;;,,'..';;;;;,',;;,;cllooodxxdddddxkxkOxdxxddolddxxxxkkddxxdddxk0KXXXXNNXNNNN\n\
XNNNXNNNXXXXXNNXXK0xoxOOOOxl:;...........'',;:cccllolllllooodlcloodxdcllloloxkkxddxkOKXXXNNNNXNXXNNN\n\
NNNNNNXNNXXXXNXXNXK00KKKK00kdl:,.....  ...'''',,,,;;;;;;:cll:;:llcodoccclooodxxxkOKXXXXXNNXXXXNNXNNN\n\
XNNNXNNNXXNNXXNNXXNNXXXNXKK0koodddl;.........',,,,,,,,;;;clolc::;;:ccclooloxkO00KXXXXXNXXNNXXNNXXXXX\n\
NNXNNNXXNNXXNNXXNNNXNNXXNXXKK000K0kdl;.'. ....''',,,,,,;,,;:;'...':cloodxxx0KKXXXXXNXXXNXXXNNXXNNXXN\n\
XNNNXNNNXXNNXNNNNXNNXXXNXXNNXXXXKKOkd:,'. .....'''''',,,,''..  .':dkkOOOOKXKXNNXXNNXXNXXXNNXXNNXXNNX\n\
NNXNNNXNNNXXNNXXNNXXNNXXNNNXNNXXXK0l'...   ..........''',,''.  .:x0XXXXXXXXNNXXNNXXNNXXNNNXNNNXNNNXN\n\
XNNNXNNNXXNNXXNNXXNNXXNNXXNNNXNNXKKd'      ............''''''...:x0KXNXXXNNXXNNXNNNXXNNXXNNXXNNXXNNN\n\
NNXNNNXXNNXXNNXXNNXXNNXXNNNXXNXKXXKOd;..    ...........''''''''';oOXXXXNXXXNNXXNNXXNNXXNNXXNNNXNNNXN\n\
XNNNXNNNXXNNXXNNXXNNXXXNNXNNXXXNXKXK0o,.    .............'',,,;;;cdOKXXXNNNXXNNXXNNXXNNXXNNNXNNNXNNX\n\
WNXNNNXXNNXXNNXXNNXXNNXXNNNXXNXXXNX0Ol.     .............'',,;::,',lxkKXXXNNXXXNNXXNNXXNNNXNNXXNNNXN\n\
XNNNXXNNXXNNXNNNXXNNXXNNXXNNXKXNX0Od;.        ............',,,,,,'',:oxkKNXXXNNXXNNXXNNXXNNXXNNNXNNX\n\
NNXNWNXXNNXXNNXXNNNXNNXKXNXKXNX00kl,.............'''''''.';::ccc;,;:lox0KKKNNXXNNXXNNXXNNNXNNNXNNNXN\n\
KNWNKNWNKXWNXKNWXXWWK0NWK0XNK0KKkoc;,,,',,,',,,,,,,,,,,,,;;;;:::;,;:clodk0K0XWNKXWNXKNWXKNWNKNWXKNWN\n");
}
void BannerImpacto(){
    printf("\
\t\t===================================================================\n\
\t\t=    ==  =====  ==       ======  =======     ===        ====    ===\n\
\t\t==  ===   ===   ==  ====  ====    =====  ===  =====  ======  ==  ==\n\
\t\t==  ===  =   =  ==  ====  ===  ==  ===  ===========  =====  ====  =\n\
\t\t==  ===  == ==  ==  ====  ==  ====  ==  ===========  =====  ====  =\n\
\t\t==  ===  =====  ==       ===  ====  ==  ===========  =====  ====  =\n\
\t\t==  ===  =====  ==  ========        ==  ===========  =====  ====  =\n\
\t\t==  ===  =====  ==  ========  ====  ==  ===========  =====  ====  =\n\
\t\t==  ===  =====  ==  ========  ====  ===  ===  =====  ======  ==  ==\n\
\t\t=    ==  =====  ==  ========  ====  ====     ======  =======    ===\n\
\t\t===================================================================\n");
}
void BannerPerdiste(){
    printf("\n\
============================================================================\n\
=       ===        ==       ===       ===    ===      ===        ==        =\n\
=  ====  ==  ========  ====  ==  ====  ===  ===  ====  =====  =====  =======\n\
=  ====  ==  ========  ====  ==  ====  ===  ===  ====  =====  =====  =======\n\
=  ====  ==  ========  ===   ==  ====  ===  ====  ==========  =====  =======\n\
=       ===      ====      ====  ====  ===  ======  ========  =====      ===\n\
=  ========  ========  ====  ==  ====  ===  ========  ======  =====  =======\n\
=  ========  ========  ====  ==  ====  ===  ===  ====  =====  =====  =======\n\
=  ========  ========  ====  ==  ====  ===  ===  ====  =====  =====  =======\n\
=  ========        ==  ====  ==       ===    ===      ======  =====        =\n\
============================================================================\n\
");
}
void BannerFallaste(){
    printf("\n\
================================================================================\n\
=        =====  =====  ========  ===========  ======      ===        ==        =\n\
=  ==========    ====  ========  ==========    ====  ====  =====  =====  =======\n\
=  =========  ==  ===  ========  =========  ==  ===  ====  =====  =====  =======\n\
=  ========  ====  ==  ========  ========  ====  ===  ==========  =====  =======\n\
=      ====  ====  ==  ========  ========  ====  =====  ========  =====      ===\n\
=  ========        ==  ========  ========        =======  ======  =====  =======\n\
=  ========  ====  ==  ========  ========  ====  ==  ====  =====  =====  =======\n\
=  ========  ====  ==  ========  ========  ====  ==  ====  =====  =====  =======\n\
=  ========  ====  ==        ==        ==  ====  ===      ======  =====        =\n\
================================================================================\n\
");
}
void BatallaNavalMultiplayer(){
  int tam = 10, w=0, barcos=20;
  int mapa[10][10], ships[10][10];
  BannerBatallaNaval();
  printf ("Tamano del juego (10*10)\n ");
  printf ("Cantidad de Barcos (20)\n");
  printf("\n");
    printf ("\t");
    for (int p = 0; p < tam; p++){
        printf ("%d ", p);
    }
    printf ("\n");
    for (int i = 0; i < tam; i++){
		printf ("\n");
		printf ("%d\t", w);
		w++;
			for (int q = 0; q < tam; q++){
				mapa[i][q] = '+';
				printf ("%c ", mapa[i][q]);
				}
    }
    printf("\n\n");
    copiaArreglo(mapa, ships, tam);
    insertarBarcos(ships, tam, barcos);
    juegoMultiplayer(mapa, ships, tam);
}
void insertarBarcos(int A[][10], int B, int C){
    int x, y;
    for(int i=0; i<C; i++){
        printf("\n\tBARCO #%d\n", i+1);
        printf("Coordenada en X:");
        scanf("%d", &x);
        printf("Coordenada en Y:");
        scanf("%d", &y);
        A[x][y] = 'o';
    }
}
void juegoMultiplayer(int A[][10], int B[][10], int C){
    int res;
    do{
        res = enviarRecibir();
        switch(res){
            case 1:
                printf("\nENVIANDO\n");
                juegoMultiplayerCliente(A, B, C);
                break;
            case 2:
                printf("\nRECIBIENDO\n");
                juegoMultiplayerServer(A, B, C);
                break;
            case 3:
                printf("\nFINALIZANDO JUEGO\n");
                BannerFinDelJuego();
                break;
        }
    }while(res!=3);
}
void juegoMultiplayerServer(int A[][10], int B[][10], int C){
    int x, y;
    x = ServerX();
    y = ServerY();
    if((x!=99)&&(y!=99)){
        if(B[x][y]=='o'){
            BannerNosDieron();
            BannerBomba();
            B[x][y]='*';
            printf("\n\tARREGLO PROPIO\n");
            printMatriz(B, C);
        }
        else if(B[x][y]=='*'){
                    printf("COORDENADA UTILIZADA\n");
                    printf("\n\tARREGLO PROPIO\n");
                    printMatriz(B, C);
                }
        else{
            BannerFallo();
            B[x][y]='X';
            printf("\n\tARREGLO PROPIO\n");
            printMatriz(B, C);
        }
    }
    else{
        printf("\nCoordenadas invalidas, siguiente turno\n");
    }
    if(B[x][y]=='*'){
    	ClientHIT();
    }
    else if(B[x][y]=='X'){
    	ClientFAIL();
    }
    printf("\n");
}
void juegoMultiplayerCliente(int A[][10], int B[][10], int C){
    int x, y, res;
    x = ClientX();
    y = ClientY();
    res = ServerX();
    if(res==0){
        BannerFallaste();
        A[x][y]='*';
        printf("\n\tARREGLO CONTRARIO\n");
        printMatriz(A, C);
    }
    else if ((res==1)||(res==99)){
        BannerImpacto();
        A[x][y]='X';
        printf("\n\tARREGLO CONTRARIO\n");
        printMatriz(A, C);
    }
    printf("\n");
}
int recvfromTimeOutUDP(SOCKET socket, long sec, long usec)
{
    struct timeval timeout;
    struct fd_set fds;
    timeout.tv_sec = sec;
    timeout.tv_usec = usec;
    FD_ZERO(&fds);
    FD_SET(socket, &fds);
    return select(0, &fds, 0, 0, &timeout);
}
int ServerX()
{
     WSADATA            wsaData;
     SOCKET             ReceivingSocket;
     SOCKADDR_IN        ReceiverAddr;
     int                Port = 5150;
     char               CoX[1024];
     int                BufLength = 1024;
     SOCKADDR_IN        SenderAddr;
     int                SenderAddrSize = sizeof(SenderAddr);
     int                ByteReceived = 5, SelectTiming, ErrorCode;
     int num;
   if( WSAStartup(MAKEWORD(2,2), &wsaData) != 0)
   {
        printf("Server: WSAStartup failed with error %ld\n", WSAGetLastError());
        return -1;
   }
   else{
          printf("Server: The Winsock DLL status is %s.\n", wsaData.szSystemStatus);
   }
     ReceivingSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

     if (ReceivingSocket == INVALID_SOCKET)
     {
          printf("Server: Error at socket(): %ld\n", WSAGetLastError());
          WSACleanup();
          return -1;
     }

     // Set up a SOCKADDR_IN structure that will tell bind that we
     // want to receive datagrams from all interfaces using port 5150.

     // The IPv4 family
     ReceiverAddr.sin_family = AF_INET;
     // Port no. 5150
     ReceiverAddr.sin_port = htons(Port);
     // From all interface (0.0.0.0)
     ReceiverAddr.sin_addr.s_addr = htonl(INADDR_ANY);

   // Associate the address information with the socket using bind.
   // At this point you can receive datagrams on your bound socket.
   if (bind(ReceivingSocket, (SOCKADDR *)&ReceiverAddr, sizeof(ReceiverAddr)) == SOCKET_ERROR)
   {
        printf("Server: bind() failed! Error: %ld.\n", WSAGetLastError());
        // Close the socket
        closesocket(ReceivingSocket);
        // Do the clean up
        WSACleanup();
        // and exit with error
        return -1;
     }

   // Some info on the receiver side...
   getsockname(ReceivingSocket, (SOCKADDR *)&ReceiverAddr, (int *)sizeof(ReceiverAddr));

   printf("Server: Receiving IP(s) used: %s\n", inet_ntoa(ReceiverAddr.sin_addr));
   SelectTiming = recvfromTimeOutUDP(ReceivingSocket, 60, 0);

   switch (SelectTiming)
        {
             case 0:
                 // Timed out, do whatever you want to handle this situation
                 printf("Server: Timeout lor while waiting you bastard client!...\n");
                 break;
             case -1:
                 // Error occurred, maybe we should display an error message?
                // Need more tweaking here and the recvfromTimeOutUDP()...
                 printf("Server: Some error encountered with code number: %ld\n", WSAGetLastError());
                 break;
             default:
                 {
                      if (SelectTiming == 1)
                      {
                           // Call recvfrom() to get it then display the received data...
                           ByteReceived = recvfrom(ReceivingSocket, CoX, BufLength, 0, (SOCKADDR *)&SenderAddr, &SenderAddrSize);
                           if (ByteReceived > 0)
                           {
                               printf("Coordenada en X: \%s \n", CoX);
                               switch(CoX[0]){
                                   case '1':
                                        num = 1;
                                        break;
                                    case '2':
                                        num = 2;
                                        break;
                                    case '3':
                                        num = 3;
                                        break;
                                    case '4':
                                        num = 4;
                                        break;
                                    case '5':
                                        num = 5;
                                        break;
                                    case '6':
                                        num = 6;
                                        break;
                                    case '7':
                                        num = 7;
                                        break;
                                    case '8':
                                        num =8;
                                        break;
                                    case '9':
                                        num = 9;
                                        break;
                                    case '0':
                                        num = 0;
                                        break;
                                    default:
                                        num = 99;
                                        break;
                               }
                           }
                           else if ( ByteReceived <= 0)
                                printf("Server: Connection closed with error code: %ld\n",
                                            WSAGetLastError());
                           else
                                printf("Server: recvfrom() failed with error code: %d\n",
                                        WSAGetLastError());

                           // Some info on the sender side
                           getpeername(ReceivingSocket, (SOCKADDR *)&SenderAddr, &SenderAddrSize);
                      }
                 }
   }

   // When your application is finished receiving datagrams close the socket.
   printf("Server: Finished receiving. Closing the listening socket...\n");
   if (closesocket(ReceivingSocket) != 0)
        printf("Server: closesocket() failed! Error code: %ld\n", WSAGetLastError());
   if(WSACleanup() != 0)
        printf("Server: WSACleanup() failed! Error code: %ld\n", WSAGetLastError());
   // Back to the system
   return num;
}
int ServerY()
{
     WSADATA            wsaData;
     SOCKET             ReceivingSocket;
     SOCKADDR_IN        ReceiverAddr;
     int                Port = 5150;
     char               CoY[1024];
     int                BufLength = 1024;
     SOCKADDR_IN        SenderAddr;
     int                SenderAddrSize = sizeof(SenderAddr);
     int                ByteReceived = 5, SelectTiming, ErrorCode;
     char ch = 'Y';
     int num;
   if( WSAStartup(MAKEWORD(2,2), &wsaData) != 0)
   {
        printf("Server: WSAStartup failed with error %ld\n", WSAGetLastError());
        return -1;
   }
   else{
          printf("Server: The Winsock DLL status is %s.\n", wsaData.szSystemStatus);
   }
     ReceivingSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);

     if (ReceivingSocket == INVALID_SOCKET)
     {
          printf("Server: Error at socket(): %ld\n", WSAGetLastError());
          WSACleanup();
          return -1;
     }

     // Set up a SOCKADDR_IN structure that will tell bind that we
     // want to receive datagrams from all interfaces using port 5150.

     // The IPv4 family
     ReceiverAddr.sin_family = AF_INET;
     // Port no. 5150
     ReceiverAddr.sin_port = htons(Port);
     // From all interface (0.0.0.0)
     ReceiverAddr.sin_addr.s_addr = htonl(INADDR_ANY);

   // Associate the address information with the socket using bind.
   // At this point you can receive datagrams on your bound socket.
   if (bind(ReceivingSocket, (SOCKADDR *)&ReceiverAddr, sizeof(ReceiverAddr)) == SOCKET_ERROR)
   {
        printf("Server: bind() failed! Error: %ld.\n", WSAGetLastError());
        // Close the socket
        closesocket(ReceivingSocket);
        // Do the clean up
        WSACleanup();
        // and exit with error
        return -1;
     }

   // Some info on the receiver side...
   getsockname(ReceivingSocket, (SOCKADDR *)&ReceiverAddr, (int *)sizeof(ReceiverAddr));

   printf("Server: Receiving IP(s) used: %s\n", inet_ntoa(ReceiverAddr.sin_addr));
   SelectTiming = recvfromTimeOutUDP(ReceivingSocket, 60, 0);

   switch (SelectTiming)
        {
             case 0:
                 // Timed out, do whatever you want to handle this situation
                 printf("Server: Timeout lor while waiting you bastard client!...\n");
                 break;
             case -1:
                 // Error occurred, maybe we should display an error message?
                // Need more tweaking here and the recvfromTimeOutUDP()...
                 printf("Server: Some error encountered with code number: %ld\n", WSAGetLastError());
                 break;
             default:
                 {
                      if (SelectTiming == 1)
                      {
                           // Call recvfrom() to get it then display the received data...
                           ByteReceived = recvfrom(ReceivingSocket, CoY, BufLength, 0, (SOCKADDR *)&SenderAddr, &SenderAddrSize);
                           if (ByteReceived > 0)
                           {
                               printf("Coordenada en Y: \%s \n", CoY);
                               switch(CoY[0]){
                                   case '1':
                                        num = 1;
                                        break;
                                    case '2':
                                        num = 2;
                                        break;
                                    case '3':
                                        num = 3;
                                        break;
                                    case '4':
                                        num = 4;
                                        break;
                                    case '5':
                                        num = 5;
                                        break;
                                    case '6':
                                        num = 6;
                                        break;
                                    case '7':
                                        num = 7;
                                        break;
                                    case '8':
                                        num =8;
                                        break;
                                    case '9':
                                        num = 9;
                                        break;
                                    case '0':
                                        num = 0;
                                        break;
                                    default:
                                        num = 99;
                                        break;
                               }
                           }
                           else if ( ByteReceived <= 0)
                                printf("Server: Connection closed with error code: %ld\n",
                                            WSAGetLastError());
                           else
                                printf("Server: recvfrom() failed with error code: %d\n",
                                        WSAGetLastError());

                           // Some info on the sender side
                           getpeername(ReceivingSocket, (SOCKADDR *)&SenderAddr, &SenderAddrSize);
                      }
                 }
   }

   // When your application is finished receiving datagrams close the socket.
   printf("Server: Finished receiving. Closing the listening socket...\n");
   if (closesocket(ReceivingSocket) != 0)
        printf("Server: closesocket() failed! Error code: %ld\n", WSAGetLastError());
   if(WSACleanup() != 0)
        printf("Server: WSACleanup() failed! Error code: %ld\n", WSAGetLastError());
   // Back to the system
   return num;
}
int ClientX()
{
     WSADATA              wsaData;
     SOCKET               SendingSocket;
     SOCKADDR_IN          ReceiverAddr, SrcInfo;
     int                  Port = 5150;
     char                 CoX[2];
     int                  BufLength = 1024;
     int len;
     int TotalByteSent;
     int x;

     // Initialize Winsock version 2.2
     if( WSAStartup(MAKEWORD(2,2), &wsaData) != 0)
     {
          printf("Client: WSAStartup failed with error %ld\n", WSAGetLastError());
          // Clean up
          WSACleanup();
          // Exit with error
          return -1;
     }

     // Create a new socket to receive datagrams on.
     SendingSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
     if (SendingSocket == INVALID_SOCKET)
     {
          printf("Client: Error at socket(): %ld\n", WSAGetLastError());
          // Clean up
          WSACleanup();
          // Exit with error
          return -1;
     }

     // Set up a SOCKADDR_IN structure that will identify who we
     // will send datagrams to. For demonstration purposes, let's
     // assume our receiver's IP address is 127.0.0.1 and waiting
     // for datagrams on port 5150.
     ReceiverAddr.sin_family = AF_INET;
     ReceiverAddr.sin_port = htons(Port);
     ReceiverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    printf("COORDENADAS EN X: \n?");
    scanf("%s", CoX);
    switch(CoX[0]){
    case '1':
    	x = 1;
    	break;
    case '2':
    	x = 2;
    	break;
    case '3':
    	x = 3;
    	break;
    case '4':
    	x = 4;
    	break;
    case '5':
    	x = 5;
    	break;
    case '6':
    	x = 6;
    	break;
    case '7':
    	x = 7;
    	break;
    case '8':
    	x = 8;
    	break;
    case '9':
    	x = 9;
    	break;
    case '0':
    	x = 0;
    	break;
    default:
    	x = 99;
    	break;
    }
     TotalByteSent = sendto(SendingSocket, CoX, BufLength, 0, (SOCKADDR *)&ReceiverAddr, sizeof(ReceiverAddr));

     // Some info on the receiver side...
     // Allocate the required resources
     memset(&SrcInfo, 0, sizeof(SrcInfo));
     len = sizeof(SrcInfo);

     getsockname(SendingSocket, (SOCKADDR *)&SrcInfo, &len);

     getpeername(SendingSocket, (SOCKADDR *)&ReceiverAddr, (int *)sizeof(ReceiverAddr));

   // When your application is finished receiving datagrams close the socket.
   printf("Client: Finished sending. Closing the sending socket...\n");
   if (closesocket(SendingSocket) != 0)
        printf("Client: closesocket() failed! Error code: %ld\n", WSAGetLastError());
   if(WSACleanup() != 0)
        printf("Client: WSACleanup() failed! Error code: %ld\n", WSAGetLastError());

   return x;
}
int ClientY()
{
     WSADATA              wsaData;
     SOCKET               SendingSocket;
     SOCKADDR_IN          ReceiverAddr, SrcInfo;
     int                  Port = 5150;
     char                 CoY[2];
     int                  BufLength = 1024;
     int len;
     int TotalByteSent;
     int y;

     // Initialize Winsock version 2.2
     if( WSAStartup(MAKEWORD(2,2), &wsaData) != 0)
     {
          printf("Client: WSAStartup failed with error %ld\n", WSAGetLastError());
          // Clean up
          WSACleanup();
          // Exit with error
          return -1;
     }

     // Create a new socket to receive datagrams on.
     SendingSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
     if (SendingSocket == INVALID_SOCKET)
     {
          printf("Client: Error at socket(): %ld\n", WSAGetLastError());
          // Clean up
          WSACleanup();
          // Exit with error
          return -1;
     }

     // Set up a SOCKADDR_IN structure that will identify who we
     // will send datagrams to. For demonstration purposes, let's
     // assume our receiver's IP address is 127.0.0.1 and waiting
     // for datagrams on port 5150.
     ReceiverAddr.sin_family = AF_INET;
     ReceiverAddr.sin_port = htons(Port);
     ReceiverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    printf("COORDENADAS EN Y: ");
    scanf("%s", CoY);
    switch(CoY[0]){
    case '1':
    	y = 1;
    	break;
    case '2':
    	y = 2;
    	break;
    case '3':
    	y = 3;
    	break;
    case '4':
    	y = 4;
    	break;
    case '5':
    	y = 5;
    	break;
    case '6':
    	y = 6;
    	break;
    case '7':
    	y = 7;
    	break;
    case '8':
    	y = 8;
    	break;
    case '9':
    	y = 9;
    	break;
    case '0':
    	y = 0;
    	break;
    default:
    	y = 99;
    	break;
    }
     TotalByteSent = sendto(SendingSocket, CoY, BufLength, 0, (SOCKADDR *)&ReceiverAddr, sizeof(ReceiverAddr));

     // Some info on the receiver side...
     // Allocate the required resources
     memset(&SrcInfo, 0, sizeof(SrcInfo));
     len = sizeof(SrcInfo);

     getsockname(SendingSocket, (SOCKADDR *)&SrcInfo, &len);

     getpeername(SendingSocket, (SOCKADDR *)&ReceiverAddr, (int *)sizeof(ReceiverAddr));

   // When your application is finished receiving datagrams close the socket.
   printf("Client: Finished sending. Closing the sending socket...\n");
   if (closesocket(SendingSocket) != 0)
        printf("Client: closesocket() failed! Error code: %ld\n", WSAGetLastError());
   if(WSACleanup() != 0)
        printf("Client: WSACleanup() failed! Error code: %ld\n", WSAGetLastError());

   return y;
}
int enviarRecibir(){
    int opcion;
    printf("\n 1. Enviar\n 2. Recibir\n 3. Finalizar juego\n");
    scanf("%d", &opcion);
    return opcion;
}
int ClientHIT()
{
     WSADATA              wsaData;
     SOCKET               SendingSocket;
     SOCKADDR_IN          ReceiverAddr, SrcInfo;
     int                  Port = 5150;
     char                 CoY[2] = {'1'};
     int                  BufLength = 1024;
     int len;
     int TotalByteSent;
     int y = 0;

     // Initialize Winsock version 2.2
     if( WSAStartup(MAKEWORD(2,2), &wsaData) != 0)
     {
          printf("Client: WSAStartup failed with error %ld\n", WSAGetLastError());
          // Clean up
          WSACleanup();
          // Exit with error
          return -1;
     }

     // Create a new socket to receive datagrams on.
     SendingSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
     if (SendingSocket == INVALID_SOCKET)
     {
          printf("Client: Error at socket(): %ld\n", WSAGetLastError());
          // Clean up
          WSACleanup();
          // Exit with error
          return -1;
     }

     // Set up a SOCKADDR_IN structure that will identify who we
     // will send datagrams to. For demonstration purposes, let's
     // assume our receiver's IP address is 127.0.0.1 and waiting
     // for datagrams on port 5150.
     ReceiverAddr.sin_family = AF_INET;
     ReceiverAddr.sin_port = htons(Port);
     ReceiverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
     TotalByteSent = sendto(SendingSocket, CoY, BufLength, 0, (SOCKADDR *)&ReceiverAddr, sizeof(ReceiverAddr));

     // Some info on the receiver side...
     // Allocate the required resources
     memset(&SrcInfo, 0, sizeof(SrcInfo));
     len = sizeof(SrcInfo);

     getsockname(SendingSocket, (SOCKADDR *)&SrcInfo, &len);

     getpeername(SendingSocket, (SOCKADDR *)&ReceiverAddr, (int *)sizeof(ReceiverAddr));

   // When your application is finished receiving datagrams close the socket.
   printf("Client: Finished sending. Closing the sending socket...\n");
   if (closesocket(SendingSocket) != 0)
        printf("Client: closesocket() failed! Error code: %ld\n", WSAGetLastError());
   if(WSACleanup() != 0)
        printf("Client: WSACleanup() failed! Error code: %ld\n", WSAGetLastError());

   return y;
}
int ClientFAIL()
{
     WSADATA              wsaData;
     SOCKET               SendingSocket;
     SOCKADDR_IN          ReceiverAddr, SrcInfo;
     int                  Port = 5150;
     char                 CoY[2] = {'0'};
     int                  BufLength = 1024;
     int len;
     int TotalByteSent;
     int y = 1;

     // Initialize Winsock version 2.2
     if( WSAStartup(MAKEWORD(2,2), &wsaData) != 0)
     {
          printf("Client: WSAStartup failed with error %ld\n", WSAGetLastError());
          // Clean up
          WSACleanup();
          // Exit with error
          return -1;
     }

     // Create a new socket to receive datagrams on.
     SendingSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
     if (SendingSocket == INVALID_SOCKET)
     {
          printf("Client: Error at socket(): %ld\n", WSAGetLastError());
          // Clean up
          WSACleanup();
          // Exit with error
          return -1;
     }

     // Set up a SOCKADDR_IN structure that will identify who we
     // will send datagrams to. For demonstration purposes, let's
     // assume our receiver's IP address is 127.0.0.1 and waiting
     // for datagrams on port 5150.
     ReceiverAddr.sin_family = AF_INET;
     ReceiverAddr.sin_port = htons(Port);
     ReceiverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");
     TotalByteSent = sendto(SendingSocket, CoY, BufLength, 0, (SOCKADDR *)&ReceiverAddr, sizeof(ReceiverAddr));

     // Some info on the receiver side...
     // Allocate the required resources
     memset(&SrcInfo, 0, sizeof(SrcInfo));
     len = sizeof(SrcInfo);

     getsockname(SendingSocket, (SOCKADDR *)&SrcInfo, &len);

     getpeername(SendingSocket, (SOCKADDR *)&ReceiverAddr, (int *)sizeof(ReceiverAddr));

   // When your application is finished receiving datagrams close the socket.
   printf("Client: Finished sending. Closing the sending socket...\n");
   if (closesocket(SendingSocket) != 0)
        printf("Client: closesocket() failed! Error code: %ld\n", WSAGetLastError());
   if(WSACleanup() != 0)
        printf("Client: WSACleanup() failed! Error code: %ld\n", WSAGetLastError());

   return y;
}
void BannerNosDieron(){
printf("\
=================================================================================================\n\
=  =======  ====    =====      ========       ===    ==        ==       =====    ====  =======  =\n\
=   ======  ===  ==  ===  ====  =======  ====  ===  ===  ========  ====  ===  ==  ===   ======  =\n\
=    =====  ==  ====  ==  ====  =======  ====  ===  ===  ========  ====  ==  ====  ==    =====  =\n\
=  ==  ===  ==  ====  ===  ============  ====  ===  ===  ========  ===   ==  ====  ==  ==  ===  =\n\
=  ===  ==  ==  ====  =====  ==========  ====  ===  ===      ====      ====  ====  ==  ===  ==  =\n\
=  ====  =  ==  ====  =======  ========  ====  ===  ===  ========  ====  ==  ====  ==  ====  =  =\n\
=  =====    ==  ====  ==  ====  =======  ====  ===  ===  ========  ====  ==  ====  ==  =====    =\n\
=  ======   ===  ==  ===  ====  =======  ====  ===  ===  ========  ====  ===  ==  ===  ======   =\n\
=  =======  ====    =====      ========       ===    ==        ==  ====  ====    ====  =======  =\n\
=================================================================================================");

}
void BannerFallo(){
printf("\
==================================================\n\
=        =====  =====  ========  ==========    ===\n\
=  ==========    ====  ========  =========  ==  ==\n\
=  =========  ==  ===  ========  ========  ====  =\n\
=  ========  ====  ==  ========  ========  ====  =\n\
=      ====  ====  ==  ========  ========  ====  =\n\
=  ========        ==  ========  ========  ====  =\n\
=  ========  ====  ==  ========  ========  ====  =\n\
=  ========  ====  ==  ========  =========  ==  ==\n\
=  ========  ====  ==        ==        ====    ===\n\
==================================================");
}
void Buscaminas(){
    srand(time(0));
  char tam[2];
  int mapa[10][10], w = 0, u = 0, o = 0, y = 0, mina[10][10];
  float dif;
  printf ("!BIENVENIDO AL JUEGO DE BUSCAMINAS!\n");
  printf ("Tama�o del juego (C/M/G): ");
  gets (tam);
  switch (tam[0]){
    case 'G':
    case 'g':
        printf ("Escogiste el tamano grande. (10*10)\n");
        printf ("\t");
        for (int p = 0; p < 10; p++){
            printf ("%d ", p);
        }
        printf ("\n");
        for (int i = 0; i < 10; i++){
        printf ("\n");
        printf ("%d\t", w);
        w++;
        for (int q = 0; q < 10; q++){
            mapa[i][q] = '+';
            printf ("%c ", mapa[i][q]);
            }
        }
        printf("\n\n");
        dif = dificultadminas (100);
        copiaArregloMinas(mapa, mina, 10);
        minas (mina, 9, dif);
        juegoMinas(mapa, mina, dif, 10);
        break;
    case 'M':
    case 'm':
        y = printf ("Escogiste el tama�o mediano. (7*7)\n");
        printf ("\t");
        for (int p = 0; p < 7; p++){
            printf ("%d ", p);
            }
        printf ("\n");
        for (int e = 0; e < 7; e++){
            printf ("\n");
            printf ("%d\t", u);
            u++;
            for (int r = 0; r < 7; r++){
                mapa[e][r] = '+';
                printf ("%c ", mapa[e][r]);
            }
        }
        printf("\n\n");
        dif = dificultadminas (49);
        copiaArregloMinas(mapa, mina, 7);
        minas (mina, 6, dif);
        juegoMinas(mapa, mina, dif, 7);
        break;
    case 'C':
    case 'c':
        printf ("Escogiste el tama�o chico. (5*5)\n");
        printf ("\t");
        for (int p = 0; p < 5; p++){
            printf ("%d ", p);}
        printf ("\n");
        for (int t = 0; t < 5; t++){
            printf ("\n");
            printf ("%d\t", o);
            o++;
            for (int y = 0; y < 5; y++){
                mapa[t][y] = '+';
                printf ("%c ", mapa[t][y]);
            }
        }
        printf("\n\n");
        dif = dificultadminas();
        copiaArregloMinas(mapa, mina, 5);
        minas (mina, 4, dif);
        juegoMinas(mapa, mina, dif, 5);
        break;
    default:
        printf ("Tama�o invalido.");
        break;
    }
}
void minas(int C[][10], int B, float A){
    srand(time(0));
    for (int i = 0; i < A; i++){
        C[rand() % B][rand() % B] = 'o';
    }
}
float dificultadminas(){
  char dif[2];
  printf ("INSERTA LA DIFICULTAD (F/M/D): ");
  scanf ("%c", dif);
setbuf(stdout,0);
  switch (dif[0]){
        case 'F':
        case 'f':
            return 8;
            break;
        case 'M':
        case 'm':
            return 14;
            break;
        case 'D':
        case 'd':
            return 20;
            break;
        default:
            printf("\nDIFICULTAD INVALIDA, INSERTE DE NUEVO\n");
            return dificultadminas();
            break;
        }
}
void copiaArregloMinas(int A[][10], int B[][10], int C){
    for(int i=0;i<C;i++){
        for(int j=0;j<C;j++){
            B[i][j]=A[i][j];
        }
    }
}
void printMatrizMinas(int A[][10], int B){
    int u=0;
    printf ("\n");
    printf ("\t");
    for (int p = 0; p < B; p++){
        printf ("%d ", p);
        }
    printf ("\n");
    for (int e = 0; e < B; e++){
        printf ("\n");
        printf ("%d\t", u);
        u++;
        for (int r = 0; r < B; r++){
            printf ("%c ", A[e][r]);
        }
    }
    printf ("\n\n");
}
void juegoMinas(int A[][10], int B[][10], float C, int D){
    int x, y,ban=0,minas=0,gan=0;
    for(int i=0;i<D;i++){
        for(int j=0;j<D;j++){
            if(B[i][j]=='o') minas++;
        }
    }
    do{
        printf("INSERTA LA COORDENADA EN X: ");
        scanf("%d", &x);
        setbuf(stdout,0);
        printf("INSERTA LA COORDENADA EN Y: ");
        scanf("%d", &y);
        setbuf(stdout,0);
        printf("\n");
        if(B[x][y]=='o'){
            if(A[x][y]=='o'){
                printf("\nCOORDENADA USADA\n");
                printMatrizMinas(A, D);
            }
            else{
                printf("\n�Oh no!, Le has dado a una mina\n");
                BannerBomba();
                A[x][y]='O';
                BannerPerdiste();
                printMatrizMinas(A, D);
                printMatrizMinas(B, D);
                ban=1;
                break;
                }
            }
        else{
            if(A[x][y]=='X'){
                printf("\nCOORDENADA USADA\n");
                printMatrizMinas(A, D);
            }
            else{
                printf("\n�Felicidades! No le has dado a una mina\n");
                A[x][y]='X';
                printMatrizMinas(A, D);
                printf("%d",minas);
                gan++;
                if(gan==(D*D)-minas){
                    printf("\n�GANASTE!\n");
                    printMatrizMinas(B, D);
                    break;
                }
            }

        }

        printf("\n");
    }while(ban==0);
    BannerFinDelJuego();
}

